#include "nokia5110.h"

#include "include.h"
static unsigned char data_array[84][6];
void DelayUs(uint32 t)
{
	while(t--);
}

#define time_delay_ms(t) DelayUs(t*1000)


void NOKIA_write_byte(unsigned char dat, unsigned char command)
  {
    unsigned char i;
    BCE_L;					
    if (command == 0)				
      BDC_L;				  
    else  
      BDC_H;			 
    for(i=0;i<8;i++)			   
     {
       if(dat&0x80)
          BDIN_H;
       else
          BDIN_L;
          BCLK_L;
          dat = dat << 1;
          BCLK_H; 
      }                       
    BCE_H;		  
  }
void NOKIA_init(void)
  { 
    PORTC_INIT();
    BRST_L;     
    //delay_us(1);
    time_delay_ms(1);
    BRST_H;
    BCE_L;     
    //delay_us(1);
    time_delay_ms(1);
    BCE_H;     
    //delay_us(1);
    time_delay_ms(1);
    NOKIA_write_byte(0x21, 0);	// ʹ����չ��������LCDģʽ
    NOKIA_write_byte(0xc8, 0);	// ����Һ��ƫ�õ�ѹ
    NOKIA_write_byte(0x06, 0);	// �¶�У��
    NOKIA_write_byte(0x13, 0);	// 1:48
    NOKIA_write_byte(0x20, 0);	// ʹ�û������V=0��ˮƽѰַ
    NOKIA_clear();	           // ����
    NOKIA_write_byte(0x0c, 0);	// �趨��ʾģʽ��������ʾ
   
    BCE_L;        // �ر�LCD
  }
void NOKIA_set_XY(unsigned char X, unsigned char Y)
  {
    NOKIA_write_byte(0x40 | Y, 0);		  
    NOKIA_write_byte(0x80 | X, 0);        
  }
void NOKIA_write_char(unsigned char c)
{
    unsigned char line;
    c -= 32;                       

    for (line=0; line<6; line++)
        NOKIA_write_byte(font6x8[c][line], 1);
   
}
void array_clear(void)
{
  int i; 
  static unsigned char *p;
   p=data_array[0];
   for(i=0;i<504;i++)
     *p++=0;
 
}
void NOKIA_clear(void)
  {
    unsigned int i;

    NOKIA_write_byte(0x0c, 0);			
    NOKIA_write_byte(0x80, 0)	;		

    for (i=0; i<504; i++)
    NOKIA_write_byte(0, 1);
     array_clear();   
  }

void NOKIA_drowpoint(unsigned char x0,unsigned char y0)
{
  static unsigned char real_y_coordinate=6;
  static unsigned char real_x_coordinate=85;
  static unsigned char last_data=0;
  unsigned char y,a;
  y=y0/8;
  a=y0%8;
  NOKIA_set_XY(x0,y);
  if((y==real_y_coordinate)&&(x0==real_x_coordinate))
  {
    NOKIA_write_byte(((0x01<<a)|last_data), 1);
    last_data=((0x01<<a)|last_data);
   
  } 
  else
  {
     NOKIA_write_byte((0x01<<a), 1);
    last_data=(0x01<<a);
  } 
    real_y_coordinate=y;
    real_x_coordinate=x0;
}
void NOKIA_drowpoint_array(unsigned char x0,unsigned char y0)
{
  
  unsigned char y,a;
  y=y0/8;
  a=y0%8;
  NOKIA_set_XY(x0,y);
  NOKIA_write_byte(((0x01<<a)|data_array[x0][y]), 1);
  data_array[x0][y]=((0x01<<a)|data_array[x0][y]);
}
void NOKIA_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2)
{
	int x_error=0,y_error=0,x_increment,y_increment,distance;
        int x_step,y_step,x_start,y_start,t;
        x_start=x1;
        y_start=y1;
        x_increment=x2-x1;
        y_increment=y2-y1;
        if(x_increment>0)
          x_step=1;
        else if(x_increment==0)
          x_step=0;
        else
        {
          x_step=-1;
          x_increment=-x_increment;
        } 
        if(y_increment>0)
          y_step=1;
        else if(y_increment==0)
          y_step=0;
        else
        {
          y_step=-1;
          y_increment=-y_increment;
        } 
        if(x_increment>y_increment)
          distance=x_increment;
        else
          distance=y_increment;
        for(t=0;t<=distance+1;t++)
        {
          NOKIA_drowpoint_array(x_start,y_start);
          x_error+=x_increment;
          y_error+=y_increment;
          if(x_error>distance)
          {
            x_error-=distance;
            x_start+=x_step;
          }
          if(y_error>distance)
          {
            y_error-=distance;
            y_start+=y_step;
          }
          
        }
        
       
} 
void draw_x_y(void)  /*��������*/
{
     NOKIA_DrawLine(10,40,70,40);
     NOKIA_DrawLine(15,45,15,5);
     NOKIA_DrawLine(15,5,12,8);
     NOKIA_DrawLine(15,5,18,8);
     NOKIA_DrawLine(67,37,70,40);
     NOKIA_DrawLine(67,43,70,40);
     NOKIA_write_english_string(20,0,"y");
     NOKIA_write_english_string(72,5,"x");
}

void NOKIA_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2)
{
	NOKIA_DrawLine(x1,y1,x2,y1);
	NOKIA_DrawLine(x1,y1,x1,y2);
	NOKIA_DrawLine(x1,y2,x2,y2);
	NOKIA_DrawLine(x2,y1,x2,y2);
}
void Draw_Circle(u16 x0,u16 y0,u8 r)
{
	int a,b;
	int di;
	a=0;b=r;	  
	di=3-(r<<1);             //�ж��¸���λ�õı�־
	while(a<=b)
	{
		 NOKIA_drowpoint_array(x0-b,y0-a);             //3           
		 NOKIA_drowpoint_array(x0+b,y0-a);             //0           
		 NOKIA_drowpoint_array(x0-a,y0+b);             //1       
		 NOKIA_drowpoint_array(x0-b,y0-a);             //7           
		 NOKIA_drowpoint_array(x0-a,y0-b);             //2             
	         NOKIA_drowpoint_array(x0+b,y0+a);             //4               
		 NOKIA_drowpoint_array(x0+a,y0-b);             //5
		 NOKIA_drowpoint_array(x0+a,y0+b);             //6 
		 NOKIA_drowpoint_array(x0-b,y0+a);             
		a++;
		//ʹ��Bresenham�㷨��Բ     
		if(di<0)di +=4*a+6;	  
		else
		{
			di+=10+4*(a-b);   
			b--;
		} 
		 NOKIA_drowpoint_array(x0+a,y0+b);
	}
} 
/********************************************
NOKIA_write_chinese_string: ��LCD����ʾ����

���������X��Y    ����ʾ���ֵ���ʼX��Y���ꣻ
          ch_with �����ֵ���Ŀ���
          num     ����ʾ���ֵĸ�����  
          line    �����ֵ��������е���ʼ����
          row     ��������ʾ���м��

	NOKIA_write_chi(0,0,12,7,0,0);
	NOKIA_write_chi(0,2,12,7,0,0);
	NOKIA_write_chi(0,4,12,7,0,0);	
-----------------------------------------------------------------------*/  
void NOKIA_write_chinese_string(unsigned char X, unsigned char Y, 
                                unsigned char ch_with,unsigned char num,
                                unsigned char line,unsigned char row)
  {
    unsigned char i,n;
     
    NOKIA_set_XY(X,Y);                             //���ó�ʼλ��
    
    for (i=0;i<num;)
      {
      	for (n=0; n<ch_with*2; n++)              //дһ������
      	  { 
      	    if (n==ch_with)                      //д���ֵ��°벿��
      	      {
      	        if (i==0) NOKIA_set_XY(X,Y+1);
      	        else
      	           NOKIA_set_XY((X+(ch_with+row)*i),Y+1);
              }
      	    NOKIA_write_byte(write_chinese[line+i][n],1);
      	  }
      	i++;
      	NOKIA_set_XY((X+(ch_with+row)*i),Y);
      }
  }
void NOKIA_write_english_string(unsigned char X,unsigned char Y,char *s)
  {
    NOKIA_set_XY(X,Y);
    while (*s) //�ַ������һ���ַ���\0
      {
	NOKIA_write_char(*s);
	 s++;
      }
  }
  /****************************************************************
 *��������:Getfloatbit
 *��������:��ȡС�����ֵ�ĳһλ
 *�������:������f��λb
 *�������:��
 *����ֵ:��һλ��ֵ
 *����˵��:
 *
 ****************************************************************/
int Getfloatbit(float f,int b)
{	
	long ces = 1;
	int i = 0;
	for(i=0;i<b;i++)
		{
			ces = ces*10;
		}
	return ((int)(f*ces))%10;
}
/****************************************************************
 *��������:lcd_printnumber
 *��������:��ӡ������
 *�������:������
 *�������:��
 *����ֵ:��
 *����˵��:
 *
 ****************************************************************/
void lcd_printnumber(unsigned char X,unsigned char Y ,float f)
{	
	int i,j,k;
	char buf[15];
	long mod = 1;
	int a[2];
	char *ma = "0123456789";
	/* �����������ֵ�λ�� */
	for(i=0;mod<=f;i++)
		{
			mod = mod*10;
		}
	if(i==0)
		{
			a[0] = 1;
		}
	else
		{
			a[0] = i;
		}
	/* ����С�����ֵ�λ�� */
	for(i=6;(i>0)&&(Getfloatbit(f,i)<1);i--)
		{
			;
		}
	if(i==0)
		{
			a[1] = 1;
		}
	else
		{
			a[1] = i;
		}
	
	/* ����������ת��Ϊ�ַ� */
	for(j=0,i=a[0];i>0;i--,j++)
		{	
			for(mod=1,k=0;k<(i-1);k++)
				{
					mod = mod*10;
				}
			buf[j] = ma[((int)(f/mod))%10];
		}
	buf[j] = '.';
	j++;
	/* ��С������ת��Ϊ�ַ� */
	for(i=1;i<=a[1];i++,j++)
		{
			buf[j] = ma[Getfloatbit(f,i)];
		}
	buf[j] = '#';
	/* ��ȡ7λ */
	buf[7]='#';
	/* ��ʾ�ַ��� */
	NOKIA_set_XY(X,Y);
	for(i=0;i<8;i++)
		{
			NOKIA_write_char(' ');
		}
	NOKIA_set_XY(X,Y);
	for(i=0;buf[i]!='#';i++)
		{
			NOKIA_write_char(buf[i]);
		}
}
void NOKIA_write_num(u8 X,u8 Y,char s)
  {
  	unsigned char line;
    NOKIA_set_XY(X,Y);
      for (line=0; line<6; line++)
        NOKIA_write_byte(font6x8[s+16][line], 1);
 
  }

