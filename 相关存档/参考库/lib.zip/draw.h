/******************************************************************
*����:���ļ��ж����˲�����ͼ�����к���
*
*******************************************************************/
#ifndef __DRAW_H
#define __DRAW_H
#include "include.h"


//������Ļ
typedef uint8 SCREEN[6][84];

void Ren_LCD(SCREEN screen);
void Cls_Rec(uint8 x1,uint8 y1,uint8 x2,uint8 y2,SCREEN screen);
void Fill_Rec(uint8 x1,uint8 y1,uint8 x2,uint8 y2,SCREEN screen);
void Invented_Clear(SCREEN screen);
void Painting(uint8 x,uint8 y,uint8 colour,SCREEN screen);
void Line(uint8 x1,uint8 y1,uint8 x2,uint8 y2,uint8 colour,SCREEN screen);
void Circle1(uint8 x1,uint8 y1,uint8 r,uint8 colour,SCREEN screen);
void Circle2(uint8 x1,uint8 y1,uint8 r,uint8 colour,SCREEN screen);
void Circle(uint8 x1,uint8 y1,uint8 r,uint8 colour,SCREEN screen);






#endif


