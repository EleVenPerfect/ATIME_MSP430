/******************************************************************
*����:���ļ����������е�ͷ�ļ�
*
*******************************************************************/
#ifndef __INCLUDE_H
#define __INCLUDE_H

#include "in430.h"
#include "MSP430.h"
#include "Def.h"
#include "CLK.h"
#include "GPIO.h"
#include "WDT.h"
#include "TA.h"
#include "TB.h"
#include "UART.h"
#include "ADC12.h"
#include "Flash.h"

#include "nokia5110.h"
#include "math.h"







#endif

