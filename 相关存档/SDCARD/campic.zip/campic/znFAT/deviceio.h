#ifndef _DEVICE_IO_H_
#define _DEVICE_IO_H_

#ifdef __cplusplus
extern "C" {
#endif

struct znFAT_IO_Ctl //�ײ������ӿڵ�IOƵ�ȿ����� 
{
 UINT32 just_sec;
 UINT8  just_dev;
};

UINT8 znFAT_Device_Init(void);
UINT8 znFAT_Device_Read_Sector(UINT32 addr,UINT8 *buffer);
UINT8 znFAT_Device_Write_Sector(UINT32 addr,UINT8 *buffer);
UINT8 znFAT_Device_Read_nSector(UINT32 nsec,UINT32 addr,UINT8 *buffer);
UINT8 znFAT_Device_Write_nSector(UINT32 nsec,UINT32 addr,UINT8 *buffer);
UINT8 znFAT_Device_Clear_nSector(UINT32 nsec,UINT32 addr);

#ifdef __cplusplus
}
#endif

#endif