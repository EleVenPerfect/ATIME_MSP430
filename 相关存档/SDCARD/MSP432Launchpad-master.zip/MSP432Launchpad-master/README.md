# MSP432Launchpad

Printf support for the MSP432 Launchpad
https://github.com/bluehash/MSP432Launchpad/tree/master/MSP432-Launchpad-Printf-Support