MSP430_SDCard_Tutorial_Using_Energia
====================================
Connecting an SD-Card to your Launchpad opens up your options to use the MSP430 platform as a cheap data logger, from temperature to acceleration. Although you can log to an SD-Card in a raw format, it is much more useful if you could store data onto it as files. This will allow you to disconnect the card from your Launchpad(using a BoosterPack) and view the files on it on a PC.

View the detailed tutorial @43oh : http://43oh.com/2013/12/interfacing-the-launchpad-to-an-sd-card-a-walkthrough/
You will need a Launchpad and an SD-Card reader like the one here: http://store.43oh.com/index.php?route=product/product&product_id=66
