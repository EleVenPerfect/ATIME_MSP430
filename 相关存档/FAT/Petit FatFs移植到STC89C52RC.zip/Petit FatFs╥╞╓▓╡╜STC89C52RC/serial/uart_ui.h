#ifndef __UART_UI_H__
#define __UART_UI_H__

//DEFINE MARCO----------------------
#define DEBUG	0

#include <stdio.h>
#include <AT89x52.h>
#include "config/includes.h"

//FUNCTION SEM-------------------------
#if DEBUG
void PrintData(INT8U *date);
#endif
 
void UartInit(void);

#endif 