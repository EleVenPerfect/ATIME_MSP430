#ifndef __SPI_OPR_H__
#define __SPI_OPR_H__

/*--	DEFINE MARCO	--*/
#define USE_SPI		1

/*--	INCLUDES	--*/
#include "config/includes.h"

#if USE_SPI
/*--	SD_PIN_DEF	--*/
sbit SD_SCLK = P1^5;   			//severice cloclk
sbit SD_MOSI = P1^6;			//master output severice input  
sbit SD_MISO = P1^7;			//master input severice output

/*--	SPI�������ݺ���		--*/
void spiTx(INT8U sddat);
/*--	SPI�������ݺ���		--*/
INT8U spiRx(void);
#endif 

#endif 